<?php

function embed_fonts() {

		echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bangers|Bungee+Shade|Codystar|Dr+Sugiyama|Indie+Flower|Lobster|Pacifico|Skranji">';

		//echo "<link rel=\"preconnect\" href=\"https://fonts.google.com/\" crossorigin>";
		//echo "<script src=\"https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js\"></script>";
		//echo "<script>WebFont.load({google:{families: ['Bangers', 'Bungee+Shade', 'Codystar', 'Dr+Sugiyama', 'Indie+Flower', 'Lobster', 'Pacifico', 'Skranji']}});</script>";
}
