# IdeaSpace 360 theme
This theme comes pre-installed with the <a href="https://github.com/IdeaSpaceVR/IdeaSpace">IdeaSpaceVR CMS</a>.

![IdeaSpace-360](screenshot.png)

More info: <a href="https://www.ideaspacevr.org/themes/ideaspace-360">https://www.ideaspacevr.org/themes/ideaspace-360</a>.
