## 1.0

- Initial version

## 1.1

- Bug fix: if Google Fonts are used and they need longer to load, the material HTML shader must be updated 
