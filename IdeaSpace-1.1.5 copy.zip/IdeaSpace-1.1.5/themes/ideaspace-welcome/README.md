# IdeaSpace Welcome theme

This theme comes pre-installed with the <a href="https://github.com/IdeaSpaceVR/IdeaSpace">IdeaSpaceVR CMS</a>.

![IdeaSpace-welcome](screenshot.png)

More info: <a href="https://www.ideaspacevr.org/themes/ideaspace-welcome">https://www.ideaspacevr.org/themes/ideaspace-welcome</a>.
