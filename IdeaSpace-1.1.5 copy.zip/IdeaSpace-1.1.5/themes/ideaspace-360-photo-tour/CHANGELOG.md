## 1.5

- A-Frame v0.8.2 update
- Only show controller models after entering VR mode (hidden in Desktop 2D mode)
- Laser pointer lines are now truncated on element intersection

## 1.4

- special characters (umlauts, etc.) in text boxes are now supported and shown
- bug fix: image loading timeout when DOM not ready

## 1.3

- vertical position for navigation and info hotspots
- fix 6-DOF controller support

## 1.2

- user height and positional controllers height fix
- print additional Chrome origin trial infos

## 1.1

- Controller responsiveness improved on navigation and info hotspots
- Version bump to A-Frame v0.7.0

## 1.0

Initial version.


