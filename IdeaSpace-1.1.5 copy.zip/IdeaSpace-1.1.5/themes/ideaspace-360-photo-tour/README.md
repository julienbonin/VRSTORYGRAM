# IdeaSpace 360 Photo Tour
This theme comes pre-installed with the <a href="https://github.com/IdeaSpaceVR/IdeaSpace">IdeaSpaceVR CMS</a>.

![IdeaSpace-360-Photo-Tour](screenshot.png)

More info: <a href="https://www.ideaspacevr.org/themes/ideaspace-360-photo-tour">https://www.ideaspacevr.org/themes/ideaspace-360-photo-tour</a>.
