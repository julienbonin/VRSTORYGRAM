# IdeaSpace 3D Model theme
This theme comes pre-installed with the <a href="https://github.com/IdeaSpaceVR/IdeaSpace">IdeaSpaceVR CMS</a>.

![IdeaSpace-3D-Model](screenshot.png)

(3D model by https://vr.google.com/objects/c6XnoUTQRsy)

More info: <a href="https://www.ideaspacevr.org/themes/ideaspace-3d-model">https://www.ideaspacevr.org/themes/ideaspace-3d-model</a>.
