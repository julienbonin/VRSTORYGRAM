@extends('layouts.frontpage_app')

@section('title', 'IdeaSpaceVR')

@section('content')

{!! $content !!}

@endsection
