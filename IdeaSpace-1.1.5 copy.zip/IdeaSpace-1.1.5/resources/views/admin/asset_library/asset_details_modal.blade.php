<div class="modal fade" id="asset-details" tabindex="-1" role="dialog" aria-labelledby="asset-details">
    <div class="modal-dialog modal-lg" role="document" style="width:90%">
        <div class="modal-content">
        </div>
    </div>
</div>

