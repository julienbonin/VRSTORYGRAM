<a-text visible="false" id="reticle-text" font="{{ asset('public/aframe/fonts/Roboto-msdf.json') }}" color="#FFFFFF" value="" width="6" align="center" position="0 0 -2">
    <a-circle id="reticle-dot" color="red" radius="0.02" position="0 -0.14 0"></a-circle>
</a-text>
