<?php

return [

    'select_option' => 'Wählen Sie eine Option aus',

];
