<?php

return [

    'spaces' => 'Spaces',
    'add_new' => 'Neu hinzufügen',
    'all' => 'Alle',
    'published' => 'Veröffentlicht',
    'trash' => 'Papierkorb',
    'title' => 'Titel',
    'theme' => 'Theme',
    'author' => 'Autor',
    'date' => 'Datum',
    'no_entries_yet' => 'Es gibt noch keine Einträge.',
    'restore' => 'Wiederherstellen',
    'delete_permanently' => 'Endgültig löschen',
    'edit' => 'Bearbeiten',
    'view' => 'Anzeigen',
    'preview' => 'Vorschau',
    'items' => 'Elemente',

];
