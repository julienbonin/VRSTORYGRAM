<?php

return [

    'add_videosphere' => 'Video Sphere Hinzufügen',
    'dragndrop_videospheres' => 'Drag &amp; Drop Video Sphere(s) hier',    
    'nearest_power_of_two' => 'Video Spheres sollten äquirektangulär sein.',
    'edit' => 'Bearbeiten',
    'insert' => 'Einfügen',
    'caption' => 'Caption',
    'description' => 'Beschreibung',
    'file_name' => 'Dateiname:',
    'file_type' => 'Dateityp:',
    'uploaded_on' => 'Hochgeladen am:',
    'file_size' => 'Dateigröße:',
    'dimensions' => 'Abmessungen:',
    'duration' => 'Dauer:',
    'edit_videosphere' => 'Video Sphere Details editieren',
    'edit_videosphere_btn' => 'Video Sphere editieren',
    'remove_videosphere_btn' => 'Video Sphere entfernen',
    'close' => 'Schließen',
    'save' => 'Speichern',
    'saved' => 'Gespeichert',
    'insert' => 'Einfügen',
    'delete_permanently' => 'Endgültig löschen',
    'vr_view' => 'VR Ansicht',
    'no_videospheres' => 'Es wurden noch keine Video Spheres hinzugefügt.',

];
