<?php

return [

    'add_photosphere' => 'Photo Sphere hinzufügen',
    'dragndrop_photospheres' => 'Drag &amp; Drop die Photo Sphere(s) hier',
    'nearest_power_of_two' => 'Breite und Höhe einer Photo Sphere werden automatisch auf die nächste Zweierpotenz gesetzt.',
    'nearest_power_of_two_hint' => 'Kontrollkästchen abwählen, um die ursprüngliche Breite und Höhe der Photo Sphere zu behalten. (Ein Seitenverhältnis von 2:1 wird empfohlen).',
    'edit' => 'Bearbeiten',
    'insert' => 'Einfügen',
    'caption' => 'Beschreibung',
    'description' => 'Beschreibung',
    'file_name' => 'Dateiname:',
    'file_type' => 'Dateityp:',
    'uploaded_on' => 'Hochgeladen am:',
    'file_size' => 'Dateigröße:',
    'dimensions' => 'Abmessungen:',
    'edit_photosphere' => 'Photo Sphere Details editieren',
    'edit_photosphere_btn' => 'Photo Sphere editieren',
    'remove_photosphere_btn' => 'Photo Sphere entfernen',
    'close' => 'Schließen',
    'save' => 'Speichern',
    'saved' => 'Gespeichert',
    'insert' => 'Einfügen',
    'delete_permanently' => 'Endgültig löschen',
    'vr_view' => 'VR Ansicht',
    'no_photospheres' => 'Es wurden noch keine Photo Spheres hinzugefügt.',
];
