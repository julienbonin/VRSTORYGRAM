<?php

return [

    'are_you_sure' => 'Wirklich löschen?',
    'action_cannot_be_undone' => 'Diese Aktion kann nicht rückgängig gemacht werden.',
    'cancel' => 'Abbrechen',
    'delete' => 'Löschen',

];
