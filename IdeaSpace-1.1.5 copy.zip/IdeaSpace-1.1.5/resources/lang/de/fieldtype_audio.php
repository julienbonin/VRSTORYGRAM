<?php

return [

    'validation_required' => 'Das Feld :label wird benötigt.',
    'validation_in' => 'Das Feld :label lässt nur :file_extensions Dateierweiterungen zu.',

];
