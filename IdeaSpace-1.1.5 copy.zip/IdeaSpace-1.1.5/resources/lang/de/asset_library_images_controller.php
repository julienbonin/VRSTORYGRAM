<?php

return [

    'wrong_file_type' => 'Falscher Dateityp. Nur *.jpg, *.png und *.gif Bilddateien sind erlaubt.',
    'file_moving_error' => 'Das Verschieben der hochgeladenen Datei schlug fehl. Überprüfen sie die Ordnerberechtigungen oder fragen sie ihren Systemadministrator.',
    'file_type_error' => 'Kann nicht hinzugefügt werden: Es muss eine Bilddatei sein.',    
    'file_size_error' => 'Kann nicht hinzugefügt werden: Datei zu groß.',    
    'file_ext_error' => 'Kann nicht hinzugefügt werden: Falsche Dateierweiterung.',    

];
