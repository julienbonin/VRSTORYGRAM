<?php

return [

    'saved' => ':label gespeichert.',
    'deleted' => ':label gelöscht.',
    'validation_required' => 'Das Feld :label ist erforderlich.',
    'validation_max' => 'Das Feld :label darf nicht länger als :max Zeichen sein.',
    'validation_content_uri_exists' => 'Dieser Pfad existiert bereits. Innerhalb eines Spaces müssen Inhaltspfade einzigartig sein.',
    'content_weight_order_saved' => 'Inhaltsauftrag gespeichert.',

];
