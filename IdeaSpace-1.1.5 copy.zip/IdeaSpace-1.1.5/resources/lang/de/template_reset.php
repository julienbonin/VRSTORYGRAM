<?php

return [

    'reset_password' => 'Passwort zurücksetzen',
    'email_address' => 'E-Mail Adresse',
    'password' => 'Passwort',
    'confirm_password' => 'Passwort bestätigen',

];
