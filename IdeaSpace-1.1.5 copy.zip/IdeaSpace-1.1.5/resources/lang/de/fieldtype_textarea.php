<?php

return [

    'validation_required' => 'Das Feld :label wird benötigt.',
    'validation_max' => 'Das Feld :label darf nicht länger als :max Zeichen sein.',

];
