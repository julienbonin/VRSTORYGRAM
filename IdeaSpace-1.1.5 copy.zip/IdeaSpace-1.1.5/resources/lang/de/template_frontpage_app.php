<?php

return [

    'dashboard' => 'Dashboard',
    'logout' => 'Ausloggen',
    'toggle_navigation' => 'Navigation umschalten',

];
