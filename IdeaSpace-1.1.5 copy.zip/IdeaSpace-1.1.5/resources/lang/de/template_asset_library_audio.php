<?php

return [

    'add_audio' => 'Audio hinzufügen',
    'dragndrop_audio_files' => 'Drag &amp; Drop Audiodatei(en) hier',
    'edit' => 'Bearbeiten',
    'insert' => 'Einfügen',
    'caption' => 'Caption',
    'caption_help' => 'Geben sie einen kurzen Untertitel zu ihrer Audiodatei an.',
    'description' => 'Beschreibung',
    'file_name' => 'Dateiname:',
    'file_type' => 'Dateityp:',
    'uploaded_on' => 'Hochgeladen am:',
    'file_size' => 'Dateigröße:',
    'dimensions' => 'Abmessungen:',
    'duration' => 'Länge:',
    'edit_audio' => 'Audiodetails editieren',
    'edit_audio_btn' => 'Audiodatei ändern',
    'remove_audio_btn' => 'Audiodatei entfernen',
    'close' => 'Schließen',
    'save' => 'Speichern',
    'saved' => 'Gespeichert',
    'insert' => 'Einfügen',
    'delete_permanently' => 'Endgültig löschen',
    'no_audio' => 'Es wurden noch keine Audiodateien hinzugefügt.',

];
