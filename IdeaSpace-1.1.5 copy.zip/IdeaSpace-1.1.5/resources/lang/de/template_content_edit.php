<?php

return [

    'edit' => 'Bearbeiten',
    'field_errors' => 'Falsche Eingaben in den Feldern.',
    'content_title_placeholder' => 'Titel hier eingeben',
    'content_title_info' => 'Geben Sie einen anschaulichen Titel oder Schlüsselwörter an, welche es einfacher machen diesen Inhalt später wieder zu finden.',
    'cancel' => 'Abbrechen',
    'delete' => 'Löschen',
    'save' => 'Speichern',
    'content_uri_placeholder' => 'Pfad hier eingeben',

];
