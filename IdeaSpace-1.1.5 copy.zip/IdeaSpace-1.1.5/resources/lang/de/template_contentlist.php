<?php

return [

    'add' => 'Hinzufügen',
    'date' => 'Datum',
    'title' => 'Titel',
    'edit' => 'Bearbeiten',
    'delete' => 'Löschen',
    'max' => 'max.',

];
