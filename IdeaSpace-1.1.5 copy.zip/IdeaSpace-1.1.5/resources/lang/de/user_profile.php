<?php

return [

    'edit_user_profile' => 'Benutzer Profil bearbeiten',
    'email_address' => 'E-mail Adresse',
    'enter_email_address' => 'E-mail Adresse eingeben',
		'email_address_required' => 'E-mail Adresse ist ein Pflichtfeld.',
    'username' => 'Benutzername',
    'enter_username' => 'Benutzername eingeben',
		'username_required' => 'Benutzername ist ein Pflichtfeld.',
    'new_password' => 'Neues Passwort',
		'enter_password' => 'Neues Passwort eingeben (optional)',
    'save_changes' => '&Auml;nderungen Speichern',
		'save_success_message' => 'Die &Auml;nderungen wurden gespeichert.',
];
