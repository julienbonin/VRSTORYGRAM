<?php

return [

    'space_deleted' => 'Space wurde gelöscht.',
    'space_trashed' => 'Space in den Papierkorb verschoben. <a href=":route">Rückgängig machen</a>.',
    'space_restored' => 'Space wurde wiederhergestellt.',

];
