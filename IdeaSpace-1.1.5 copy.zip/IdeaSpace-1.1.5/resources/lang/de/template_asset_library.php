<?php

return [

    'images' => 'Bilder',
    'photospheres' => 'Foto Spheres',
    'videos' => 'Videos',
    'videospheres' => 'Video Spheres',
    'audio' => 'Audio',
    'models' => 'Modelle',
    'or' => 'oder',
    'open_file_browser' => 'Klick um den Dateibrowser zu öffnen',
    'assets' => 'Assets',
    'add_new' => 'Neu hinzufügen',
    'close' => 'Schließen',

];
