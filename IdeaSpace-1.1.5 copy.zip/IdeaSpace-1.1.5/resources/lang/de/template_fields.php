<?php

return [

    'max' => 'Max.',
    'characters' => 'Zeichen',
    'optional' => 'Optionales Feld',
    'required' => 'Benötigtes Feld',
    'formatted_text' => 'Formatierter Text',
    'plain_text' => 'Klartext',

];
