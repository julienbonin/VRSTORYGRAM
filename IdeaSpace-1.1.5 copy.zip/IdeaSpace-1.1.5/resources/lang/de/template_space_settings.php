<?php

return [

    'space_settings' => 'Space Einstellungen',
    'frontpage_displays' => 'Auf der Hauptseite angezeigt',
    'your_latest_spaces' => 'Ihre letzten Spaces',
    'one_space_select_below' => 'Ein Space (bitte auswählen)',
    'blank_page' => 'Blank page',
    'save_changes' => 'Änderungen Speichern',
    'settings_saved' => 'Einstellungen gespeichert.',

];
