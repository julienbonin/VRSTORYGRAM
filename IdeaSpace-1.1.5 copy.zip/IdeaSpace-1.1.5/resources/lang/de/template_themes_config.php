<?php

return [

    'themes' => 'Themes',
    'get_themes' => 'Mehr Themes',
    'installed' => 'Installiert',
    'version' => 'Version:',
    'author' => 'Autor:',
    'uninstall' => 'Deinstallieren',
    'install_theme' => 'Theme installieren',
    'invalid_theme' => 'Konfigurationsfehler!',
    'incompatible_theme' => 'Inkombatibel mit der IdeaSpaceVR Version!',
    'add_new_space' => 'Neuen Space hinzufügen',

];
