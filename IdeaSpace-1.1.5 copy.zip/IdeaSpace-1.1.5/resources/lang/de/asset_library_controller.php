<?php

return [

    'upload_max_filesize' => 'Maximale Dateigröße für hochgeladene Dateien: :upload_max_filesize',
    'upload_max_filesize_tooltip' => 'Sie können diese Einstellungen in ihrer PHP-Konfigurationsdatei vornehmen (php.ini). Fragen sie ihren Webadministrator nach Hilfe.',
    'post_max_size' => 'Max. post size: :post_max_size',

];
