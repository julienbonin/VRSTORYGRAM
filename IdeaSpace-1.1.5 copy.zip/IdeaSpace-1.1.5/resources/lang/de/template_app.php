<?php

return [

    'home' => 'Home',
    'dashboard' => 'Dashboard',
    'login' => 'Einloggen',
    'spaces' => 'Spaces',
    'all' => 'Alle',
    'add_new' => 'Neu Hinzufügen',
    'assets' => 'Assets',
    'themes' => 'Themes',
    'settings' => 'Einstellungen',
    'general' => 'Allgemein',
    'space' => 'Space',
    'logout' => 'Ausloggen',
		'edit_profile' => 'Profil Bearbeiten',
    'toggle_navigation' => 'Navigation Umschalten',
    'version' => 'Version',

];
