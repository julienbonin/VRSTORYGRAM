<?php

return [

    'select_space' => 'Space ausw�hlen',

];
