<?php

return [

    'login' => 'Einloggen',
    'email_address' => 'E-Mail Adresse',
    'password' => 'Passwort',
    'remember_me' => 'Angemeldet bleiben',
    'forgot_your_password' => 'Passwort vergessen?',

];
