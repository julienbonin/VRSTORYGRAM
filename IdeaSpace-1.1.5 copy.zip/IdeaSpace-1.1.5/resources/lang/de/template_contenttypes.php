<?php

return [

    'add' => 'Hinzufügen',
    'drag_n_drop' => 'Inhalte per Drag and Drop sortieren.',

];
