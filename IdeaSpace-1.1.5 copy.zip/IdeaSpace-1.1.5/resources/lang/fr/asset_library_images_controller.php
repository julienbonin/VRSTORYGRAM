<?php

return [

    'wrong_file_type' => 'Mauvais type de fichier. Seulement les formats *.jpg, *.png et *.gif sont permis.',
    'file_moving_error' => 'Quelque chose n’a pas fonctionné durant le processus de téléversement. Veuillez vérifier les permissions du fichier ou contactez votre administrateur de système.',
    'file_type_error' => 'ne peut être ajouté : doit être un fichier image.',    
    'file_size_error' => 'ne peut être ajouté : le poids du fichier est trop grand.',    
    'file_ext_error' => 'ne peut être ajouté : mauvaise extension du fichier.',    

];
