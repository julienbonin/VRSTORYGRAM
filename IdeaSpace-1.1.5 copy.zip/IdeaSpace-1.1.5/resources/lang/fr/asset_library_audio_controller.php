<?php

return [

    'wrong_file_type' => 'Erreur de type de fichier. Seulement les fichiers *.mp3 audio sont autorisés.',
    'file_moving_error' => "Quelque chose n'a pas fonctionné lors du téléversement du fichier. Veuillez vérifier les permissions du dossier ou adressez  à votre administrateur de système.",
    'file_type_error' => 'ne peut être ajouté : doit être un fichier audio.',    
    'file_size_error' => 'ne peut être ajouté : le poids du fichier est trop grand.',    
    'file_ext_error' => 'ne peut être ajouté : mauvaise extension de fichie',

];
