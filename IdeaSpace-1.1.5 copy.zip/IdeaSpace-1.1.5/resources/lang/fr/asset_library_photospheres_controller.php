<?php

return [

    'wrong_file_type' => 'Mauvais type de fichier. Seulement les formats *.jpg, *.png et *.gif sont permis.',
    'file_moving_error' => 'Quelque chose n’a pas fonctionné lors du transfert de fichier. Veuillez vérifier les permissions du dossier ou vous adresser à votre administrateur système.',
    'file_type_error' => 'ne peu être ajouté : doit être une image.',    
    'file_size_error' => 'ne peu être ajouté : fichier trop grand.',    
    'file_ext_error' => 'ne peu être ajouté : mauvaise extension du fichier.',    

];
