<?php

return [

    'select_option' => 'Sélectionnez une option',

];
