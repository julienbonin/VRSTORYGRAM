<?php

return [

    'wrong_file_type' => 'Mauvais type de fichier. Seulement les fichiers de type *.mp4 vidéo sont autorisés.',
    'file_moving_error' => 'Quelque chose n’a pas fonctionné lors du déplacement du fichier. Veuillez vérifier les permissions du dossier ou vous adresser à votre administrateur de système.',
    'file_type_error' => 'ne peut être ajouté : doit être un fichier vidéo.',    
    'file_size_error' => 'ne peut être ajouté : fichier trop grand.',    
    'file_ext_error' => 'ne peut être ajouté : mauvaise extension du fichier.',    

];
