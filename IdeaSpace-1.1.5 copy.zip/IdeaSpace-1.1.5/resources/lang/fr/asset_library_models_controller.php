<?php

return [

    'wrong_file_type' => 'Mauvais type de fichier.',
    'file_moving_error' => 'Quelque chose n’a pas fonctionné lors du déplacement du fichier. Veuillez vérifier les permissions du dossier ou vous adresser à votre administrateur de système.',
    'file_directory_creation_error' => 'Quelque chose n’a pas fonctionné lors de la création du dosser pour ce fichier. Veuillez vérifier les permissions du dossier ou vous adresser à votre administrateur de système.',
    'file_type_error' => 'ne peut être ajouté : doit être un format supporté.',    
    'file_size_error' => 'ne peut être ajouté : poids du fichier trop grand.',    
    'file_ext_error' => 'ne peut être ajouté : mauvaise extension du fichier.',    

];
