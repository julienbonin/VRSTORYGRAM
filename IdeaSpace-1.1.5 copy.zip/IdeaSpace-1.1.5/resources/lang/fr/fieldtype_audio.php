<?php

return [

    'validation_required' => 'Le champ :label doit être remplis.',
    'validation_in' => 'Le champ :label permet seulement les extensions :file_extensions.',

];
