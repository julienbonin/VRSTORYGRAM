<?php

return [

    'upload_max_filesize' => 'Poids maximum du fichier : :upload_max_filesize',
    'upload_max_filesize_tooltip' => 'Vous pouvez configurer ces paramètres dans votre fichier de configuration php (php.ini). Pour être aidé, adressez-vous à votre administrateur web.',
    'post_max_size' => 'La taille max. des données reçues par la méthode POST',

];
