<?php

return [

    'edit_user_profile' => 'Edit User Profile',
    'email_address' => 'E-mail Address',
    'enter_email_address' => 'Enter an e-mail address',
    'email_address_required' => 'The e-mail field is required.',
    'username' => 'Username',
    'enter_username' => 'Enter a username',
    'username_required' => 'The username field is required.',
    'new_password' => 'New Password',
    'enter_password' => 'Enter a new password (optional)',
    'save_changes' => 'Save Changes',
    'save_success_message' => 'The changes have been saved.',

];
