<?php

return [

    'validation_space_title_required' => 'The title field is required.',
    'validation_space_title_max' => 'The title field may not be larger than :max characters.',
    'validation_space_uri_required' => 'The path field is required.',
    'validation_space_uri_max' => 'The path field may not be larger than :max characters.',
    'validation_space_uri_exists' => 'This path already exists.',
    'space_saved' => 'Space saved.',

];
