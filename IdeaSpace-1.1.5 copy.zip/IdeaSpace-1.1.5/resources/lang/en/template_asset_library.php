<?php

return [

    'images' => 'Images',
    'photospheres' => 'Photo Spheres',
    'videos' => 'Videos',
    'videospheres' => 'Video Spheres',
    'audio' => 'Audio',
    'models' => 'Models',
    'or' => 'or',
    'open_file_browser' => 'Click to open File Browser',
    'assets' => 'Assets',
    'add_new' => 'Add New',
    'close' => 'Close',

];
