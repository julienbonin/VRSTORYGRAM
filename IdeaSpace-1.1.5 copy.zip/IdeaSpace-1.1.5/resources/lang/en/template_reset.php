<?php

return [

    'reset_password' => 'Reset Password',
    'email_address' => 'E-Mail Address',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',

];
