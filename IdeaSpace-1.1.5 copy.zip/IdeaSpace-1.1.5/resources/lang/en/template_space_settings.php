<?php

return [

    'space_settings' => 'Space Settings',
    'frontpage_displays' => 'Front Page Displays',
    'your_latest_spaces' => 'Your latest spaces',
    'one_space_select_below' => 'One space (select below)',
    'blank_page' => 'Blank page',
    'save_changes' => 'Save Changes',
    'settings_saved' => 'Settings saved.',

];
