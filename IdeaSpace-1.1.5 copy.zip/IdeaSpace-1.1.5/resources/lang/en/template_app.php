<?php

return [

    'home' => 'Home',
    'dashboard' => 'Dashboard',
    'login' => 'Login',
    'spaces' => 'Spaces',
    'all' => 'All',
    'add_new' => 'Add New',
    'assets' => 'Assets',
    'themes' => 'Themes',
    'settings' => 'Settings',
    'general' => 'General',
    'space' => 'Space',
    'logout' => 'Logout',
    'edit_profile' => 'Edit Profile',
    'toggle_navigation' => 'Toggle Navigation',
    'version' => 'Version',

];
