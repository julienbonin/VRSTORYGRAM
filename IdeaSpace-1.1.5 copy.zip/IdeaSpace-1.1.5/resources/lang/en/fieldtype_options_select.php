<?php

return [

    'select_option' => 'Select an option',

];
