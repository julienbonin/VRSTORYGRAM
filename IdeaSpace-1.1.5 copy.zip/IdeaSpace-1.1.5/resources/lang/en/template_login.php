<?php

return [

    'login' => 'Login',
    'email_address' => 'E-Mail Address',
    'password' => 'Password',
    'remember_me' => 'Remember Me',
    'forgot_your_password' => 'Forgot Your Password?',

];
