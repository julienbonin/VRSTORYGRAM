<?php

return [

    'upload_max_filesize' => 'Max. upload file size: :upload_max_filesize',
    'upload_max_filesize_tooltip' => 'You can configure these settings in your php configuraton file (php.ini). Ask your web administrator for help.',
    'post_max_size' => 'Max. post size: :post_max_size',

];
