<?php

return [

    'add' => 'Add',
    'drag_n_drop' => 'Sort content with drag and drop.',

];
