<?php

return [

    'wrong_file_type' => 'Wrong file type. Only *.mp3 audio types are allowed.',
    'file_moving_error' => 'Something went wrong while moving the uploaded file. Please check your directory permissions or ask your system administrator.',
    'file_type_error' => 'cannot be added: must be an audio file.',    
    'file_size_error' => 'cannot be added: file size too large.',    
    'file_ext_error' => 'cannot be added: wrong file extension.',    

];
