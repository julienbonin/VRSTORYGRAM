<?php

return [

    'saved' => ':label saved.',
    'deleted' => ':label deleted.',
    'validation_required' => 'The :label field is required.',
    'validation_max' => 'The :label field may not be larger than :max characters.',
    'validation_content_uri_exists' => 'This path already exists. Content paths must be unique on a per space basis.',
    'content_weight_order_saved' => 'Content order saved.',

];
