<?php

return [

    'are_you_sure' => 'Are you sure you want to delete',
    'action_cannot_be_undone' => 'This action cannot be undone.',
    'cancel' => 'Cancel',
    'delete' => 'Delete',
		'referenced_content_message' => '":title" is currently referenced in another content with the title ":title_other" (:other_type). If you delete ":title", the reference in ":title_other" will be deleted as well.',

];
