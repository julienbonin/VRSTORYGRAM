<?php

return [

    'themes' => 'Themes',
    'get_themes' => 'Get more themes',
    'installed' => 'Installed',
    'version' => 'Version:',
    'author' => 'Author:',
    'uninstall' => 'Uninstall',
    'install_theme' => 'Install Theme',
    'invalid_theme' => 'Configuration Error!',
    'incompatible_theme' => 'Incompatible with IdeaSpaceVR version!',
    'add_new_space' => 'Add New Space',

];
