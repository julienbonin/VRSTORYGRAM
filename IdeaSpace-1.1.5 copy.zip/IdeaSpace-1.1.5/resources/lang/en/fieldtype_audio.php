<?php

return [

    'validation_required' => 'The :label field is required.',
    'validation_in' => 'The :label field allows only :file_extensions file extensions.',

];
