<?php

return [

    'max' => 'Max.',
    'characters' => 'characters',
    'optional' => 'Optional field',
    'required' => 'Required field',
    'formatted_text' => 'Formatted text',
    'plain_text' => 'Plain text',

];
