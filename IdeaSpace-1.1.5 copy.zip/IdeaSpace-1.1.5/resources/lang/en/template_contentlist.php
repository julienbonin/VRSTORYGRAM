<?php

return [

    'add' => 'Add',
    'date' => 'Date',
    'title' => 'Title',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'max' => 'max.',

];
