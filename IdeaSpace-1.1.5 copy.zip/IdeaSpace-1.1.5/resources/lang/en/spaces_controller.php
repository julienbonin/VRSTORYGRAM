<?php

return [

    'space_deleted' => 'Space has been deleted.',
    'space_trashed' => 'Space moved to trash. <a href=":route">Undo</a>.',
    'space_restored' => 'Space has been restored.',

];
