<?php

return [

    'add_new' => 'Add New',
    'field_errors' => 'There are errors in the fields below.',
    'content_title_placeholder' => 'Enter title here',
    'content_title_info' => 'Enter a descriptive title or keywords which makes it easy for you to identify this content.',
    'cancel' => 'Cancel',
    'save' => 'Save',
    'content_uri_placeholder' => 'Enter path here',

];
