<?php

return [

    'dashboard' => 'Dashboard',
    'logout' => 'Logout',
    'toggle_navigation' => 'Toggle Navigation',

];
