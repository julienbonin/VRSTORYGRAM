<?php

return [

    'add_videosphere' => 'Add Video Sphere',
    'dragndrop_videospheres' => 'Drag &amp; Drop Video Sphere(s) Here',    
    'nearest_power_of_two' => 'Video spheres should be equirectangular.',
    'edit' => 'Edit',
    'insert' => 'Insert',
    'caption' => 'Caption',
    'description' => 'Description',
    'file_name' => 'File name:',
    'file_type' => 'File type:',
    'uploaded_on' => 'Uploaded on:',
    'file_size' => 'File size:',
    'dimensions' => 'Dimensions:',
    'duration' => 'Duration:',
    'edit_videosphere' => 'Edit Video Sphere Details',
    'edit_videosphere_btn' => 'Edit Video Sphere',
    'remove_videosphere_btn' => 'Remove Video Sphere',
    'close' => 'Close',
    'save' => 'Save',
    'saved' => 'Saved',
    'insert' => 'Insert',
    'delete_permanently' => 'Delete Permanently',
    'vr_view' => 'VR View',
    'no_videospheres' => 'No video spheres added yet.',

];
