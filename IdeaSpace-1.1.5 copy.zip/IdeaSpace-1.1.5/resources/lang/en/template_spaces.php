<?php

return [

    'spaces' => 'Spaces',
    'add_new' => 'Add New',
    'all' => 'All',
    'published' => 'Published',
    'trash' => 'Trash',
    'title' => 'Title',
    'theme' => 'Theme',
    'author' => 'Author',
    'date' => 'Date',
    'no_entries_yet' => 'There are no entries yet.',
    'restore' => 'Restore',
    'delete_permanently' => 'Delete Permanently',
    'edit' => 'Edit',
    'view' => 'View',
    'preview' => 'Preview',
    'items' => 'items',

];
