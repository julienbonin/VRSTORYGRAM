<?php

return [

    'select_space' => 'Select a space',

];
