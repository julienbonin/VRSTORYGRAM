<?php

return [

    'validation_required' => 'The :label field is required.',
    'validation_max' => 'The :label field may not be larger than :max characters.',

];
